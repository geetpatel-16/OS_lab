echo "enter file name:"
read a
wc -w "$a"

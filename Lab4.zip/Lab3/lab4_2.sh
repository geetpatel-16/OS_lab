if grep -lq "$1" a.c
then
   echo "PRESENT"
else
   echo "ABSENT"
fi

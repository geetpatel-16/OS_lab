echo "Enter number"
read num
echo "($num * ($num + 1)) / 2" | bc


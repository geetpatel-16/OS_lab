echo "Enter a number:"
read n
count=0
i=2
sum=`expr $n / 2`
while [ "$i" -le "$sum" ] 
do
 tmp=`expr $n % $i`
 if [ $tmp -eq 0 ]
 then
 count=`expr $count + 1`
 break
 fi
 i=`expr $i + 1`
done
if [[ "$count" -eq 0 && "$n" -ne 1 ]]
then
 echo Prime Number
else
 echo Not a prime number
fi

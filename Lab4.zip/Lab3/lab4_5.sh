echo "Enter actual rent of the house: "
read actual

echo "Enter your basic salary: "
read basic
a=0.12
echo "$actual - $a * $basic" | bc


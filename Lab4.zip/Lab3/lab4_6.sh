h=$(date +"%H")
m=$(date +"%M")
s=$(date +"%S")

if [ $h -lt 12 ]
then 
echo "good morning"
elif [ $h -lt 16 ]
then
echo "good afternoon"
else 
echo "good evening"
fi

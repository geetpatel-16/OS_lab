ls -l "$1"

echo "Do you want to change the permission of a file: "
read p

if [ $p == y ]
then
chmod 777 $1
ls -l "$1"
fi


echo 'Write a filename in which you want to calculate newline characters'
read a
wc -l $a

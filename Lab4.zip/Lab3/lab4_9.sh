echo "Enter filename with extension"
read a
wc -l "$a"

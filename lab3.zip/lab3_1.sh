echo " Enter one no.="
read A
echo "Enter second no.="
read B
    sum=`expr $A + $B`

     echo "Sum ="$sum

     sub=`expr $A - $B`

     echo "Sub = "$sub

     mul=`expr $A \* $B`

     echo "Mul = "$mul

     mod=`expr $A % $B`

     echo "mod="$mod

     div=`expr $A / $B`

    echo "div = "$div      	
    

    

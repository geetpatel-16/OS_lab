list=(12110 121011 121012 121013 121014 121015 121016 121017 121018 121019)
read -p "Search your ID:" ID
for i in {0..9}
do
if [ "$ID" == "${list[$i]}" ]  
then
echo "You are on the list "
echo  "Position" `expr $i + 1`
c=0
exit 1
else 
c=1
fi
done
if [ "$c" == 1 ]
then
echo "value not found" 
fi



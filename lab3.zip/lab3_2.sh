echo " Addition of $1 and $2 is" `expr $1 + $2`
echo " Subtraction of $1 and $2 is " `expr $1 - $2`
echo " Multiplication of $1 and $2 is " `expr $1 \* $2` 
echo " Division of $1 and $2 is " `expr $1 \/ $2`
echo " Modulo of $1 and $2 is " `expr $1 \% $2`


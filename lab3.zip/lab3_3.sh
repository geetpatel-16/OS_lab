clear
sum=0
i="y"

echo " Enter one no."
read A
echo "Enter second no."
read B
while [ $i = "y" ]
do
echo "1.Addition"
echo "2.Subtraction"
echo "3.Multiplication"
echo "4.Division"
echo "Enter your choice"
read ch
case $ch in
    1)sum=`expr $A + $B`
     echo "Sum ="$sum;;
        2)sub=`expr $A - $B`
     echo "Sub = "$sub;;
    3)mul=`expr $A \* $B`
     echo "Mul = "$mul;;
    4)div`expr $A / $B`
     echo "Div = "$div;;
    5)mod=`expr $A % $B`
     echo "Div = "$mod;;
	
    *)echo "Invalid choice";;
esac
echo "Do u want to continue ?"
read i
if [ $i != "y" ]
then
    exit
fi
done 

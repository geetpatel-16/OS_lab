echo " Enter one no.="
read A
echo "Enter second no.="
read B
if [ $A -gt $B ]
then echo "A is greater"
elif [ $B -gt $A ]
then echo "B is greater"
else
echo "A and B are equal"
fi 

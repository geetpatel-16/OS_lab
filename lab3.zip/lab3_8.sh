 echo “Enter n for Fibonacci series: - “
read n
echo "Fibonacci series is: "
echo "0"
echo "1"
i=0
j=1
cnt=2
while [ $cnt –le $n ]
do
k=`expr $i + $j`
i= $j
j= $k
echo $k
cnt=`expr $cnt + 1`
done

clear
echo "Enter a string:"
read str
y=`expr $str |rev`
if [ "$y" == "$str" ]
then echo "palindrom"
else
echo "not palindrom"
fi

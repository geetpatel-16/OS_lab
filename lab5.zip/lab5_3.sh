a=$1
for((i=0; i < $2; i++))
do
echo "$a"
done

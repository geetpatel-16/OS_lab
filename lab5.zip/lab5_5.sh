clear
echo "enter the first file:"
read file1
echo "enter the 2nd file:"
read file2
if [ -e $file1 ]
then echo "file1 is there"
else
echo "file1 is not there"
fi
if [ -e $file2 ]
then 
	count=1
	echo "file2 is there"
else
	echo "file2 is not there"
fi

if [ $count -eq 1 ]
then cat $file1 >> $file2
else cat $file1 > $file2
fi

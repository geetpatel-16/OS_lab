clear
echo "input a char"
read a
ls $a*

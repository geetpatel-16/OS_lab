#include<stdio.h>
#include<stdlib.h>
int value=1;
int product;
int queue[2]={0};


void enqueue(int b){

	int cnt=0;
	for(int i=0;i<2;i++)
	{
		if(queue[i]==0)
		{
			cnt=1;
			queue[i]=b;
			break;
		}
	}
	if(cnt==0)
	{
		printf("\nsorry request cant be accepted.Queue is Full\n");
	}	
		
}

void dequeue(){

	queue[0]=queue[1];
	queue[1]=0;	
}

void semwait(){

	value--;
}

void semsignal(){

	value++;
}

void producer()
{
	semwait();
	if(product==0)
	{
		product=1;
	}
	else if(product==1)
	{
		printf("\nBuffer is Full\n");
	} 
	semsignal();
}

void consumer1(){

	semwait();
	if(product==1){
	
		if(queue[0]==0 || queue[0]==1 ){
		
			product=0;
			dequeue();
		}
		else{
		
			enqueue(1);
		}
	}
	
	else{
	
		enqueue(1);
	}
	semsignal();
}

void consumer2(){

	semwait();
	if(product==1){
	
		if(queue[0]==0 || queue[0]==2){
		
			product=0;
			dequeue();
		}
		else{
		
			enqueue(2);
		}
	}	
	else{
	
		enqueue(2);	
	}
	semsignal();
}

void queue_status(){

	
	for(int i=0;i<2;i++){
	
		printf("\n");
		if(queue[i]==1){
		
			printf("%d. Consumer1\n",i+1);
		}
		else if(queue[i]==2){
		
			printf("%d. Consumer2\n",i+1);
		}	
		else{
		
			printf("%d. Empty!\n",i+1);
		}
	}
}


void main()
{
	int choice;
	void semsignal(void);
	void producer(void);
	void semwait(void);
	void enqueue(int);
	void dequeue(void);
	void queue_status(void);
	void consumer1(void);
	void consumer2(void);
	while(1){
	
		printf("1. Call Producer\n");
		printf("2. Call Consumer1\n");
		printf("3. Call Consumer2\n");
		printf("4. Buffer Status\n");
		printf("5. Queue Status\n");
		printf("ctrl+c for Exit\n");
		printf("Enter Choice:");
		scanf("%d", &choice);
		switch(choice){
		
			case 1:
				producer();
				break;
			case 2:
				consumer1();
				break;
			case 3:
				consumer2();
				break;
			case 4:
				queue_status();
			case 5:
				if(product==1){
				
					printf("\nBuffer Full\n");
				}
				else{
				
					printf("\nBuffer Empty\n");
				}
		}
	
	}	
}









